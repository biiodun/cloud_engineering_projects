http://my-bucket-381321155592.s3-website-us-east-1.amazonaws.com/

https://my-bucket-381321155592.s3.amazonaws.com/index.html

https://d878yb8m5dwl9.cloudfront.net/